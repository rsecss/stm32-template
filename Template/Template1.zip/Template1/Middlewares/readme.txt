    该文件夹下面存放中间层组件代码，包括：
    1，中间层代码：USMART、MALLOC、TEXT、T9INPUT、PICTURE、GUI、MJPEG、各种ATK开头的LIB、NES、SMS、QR_ENCODE等
    2，第三方中间层代码：FATFS、USB、LWIP、各种OS、各种GUI等 

    注意：该文件夹下面，至少使用 USMART，才会存放代码进来，在此之前的例程，没有用到类似的代码，但是我们会预留该文件夹，方便后续工程使用。
