Digitally signed USB driver for ST-Link/V2 on Windows7 and Windows8, 32 and 64 bits.
To install the driver, run stlink_winusb_install.bat in administrator mode, before
connecting any ST-Link/V2 to the PC.